﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class InitialStoryText : MonoBehaviour 
{
	public Text storyText;

	void Start () 
	{
		storyText.text = "Sasha woke up to find no sign of her beloved master. It was 7pm; she should be home by now! Sasha couldn't shake the idea that something bad had happened. She took it upon herself to find her.";
	}
}
