﻿using UnityEngine;
using System.Collections;

public class SashaMovement : MonoBehaviour 
{
	public Transform sasha;
	[Range(0.0f, 1000.0f)]
	public float rotateSpeed;
	[Range(0.0f, 10.0f)]
	public float moveSpeed;
	public Animator anim;

	void Start () 
	{
		sasha.position = new Vector3 (0f, -0.5f, 0f);
		anim.enabled = false;
	}

	void FixedUpdate () 
	{
		if (Input.GetKey ("a")) 
		{
			sasha.Rotate (Vector3.forward * Time.deltaTime * rotateSpeed);
		}
		if (Input.GetKey ("d")) 
		{
			sasha.Rotate (Vector3.back * Time.deltaTime * rotateSpeed);
		}
		if (Input.GetKey ("w")) 
		{
			sasha.position += (transform.right * Time.deltaTime * moveSpeed);
			anim.enabled = true;
		}
		if (Input.anyKey == false) 
		{
			anim.enabled = false;
		}
	}
}
