﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class EndingExposition : MonoBehaviour 
{

	public Text[] textArray;
	public int clicks;

	void Start () 
	{
		foreach (var textBoxes in textArray) 
		{
			textBoxes.enabled = false;
		}
		clicks = 0;
	}

	void Update ()
	{
		
	}
}
