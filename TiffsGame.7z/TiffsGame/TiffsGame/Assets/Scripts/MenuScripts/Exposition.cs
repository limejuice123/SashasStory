﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class Exposition : MonoBehaviour 
{
	public Text text1;
	public Text text2;
	public Text text3;
	public Text text4;

	public int clicks;

	void Start () 
	{
		clicks = 0;
		text1.enabled = false;
		text2.enabled = false;
		text3.enabled = false;
		text4.enabled = false;
	}

	void Update () 
	{
		if (Input.GetMouseButtonUp (0)) 
		{
			clicks++;
		}
		switch (clicks) 
		{
		case 0:
			text1.enabled = true;
			break;
		case 1:
			text2.enabled = true;
			break;
		case 2:
			text3.enabled = true;
			break;
		case 3:
			text4.enabled = true;
			break;
		case 4:
			SceneManager.LoadScene ("GameScreen", LoadSceneMode.Single);
			break;
		}
	}
}
