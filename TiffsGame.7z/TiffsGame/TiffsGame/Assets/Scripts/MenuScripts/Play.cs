﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class Play : MonoBehaviour 
{

	public GameObject playButton;

	void OnMouseDown () 
	{
		SceneManager.LoadScene ("ExpositionScreen", LoadSceneMode.Single);
	}
}
